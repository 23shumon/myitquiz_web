<?php
	$con= new mysqli('localhost','id10141423_root','myitquiz','id10141423_quizdb')or die("Could not connect to mysql".mysqli_error($con));
	error_reporting(0);
	
?>